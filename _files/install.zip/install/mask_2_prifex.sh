#!/bin/bash
 
# ����תprifexֵ
function mask2prifex
{ 
	local p=0
	local q=$1
	 
	while read i
	 
	do a=$(echo "obase=2;$i" | bc -l)
	 
	b=$(($(echo ${a%%0*}|wc -c)-1))
	 
	p=$(($p+$b))
	 
	done< <(echo $q|tr '.' '\n'|sed '/^$/d')
	 
	PRIFEX=$p
}
