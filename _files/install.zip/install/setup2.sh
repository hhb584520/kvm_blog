#!/bin/bash
#set -x
echo "ȷ����ȷ������configĿ¼��scaleone.properties�ļ��еĲ���(y/n):"
read test
if [ "n" = $test ]; then  
    exit 1  
fi  
. ../config/scaleone.properties
#mjx function
. ./add_torclocal.sh
. ./mask_2_prifex.sh

is_mast_ctrl_node=`ifconfig | grep $mastnodeIP -c`

BASE_DIR=$PWD/..
INSTALL_PACKAGE_PATH=$BASE_DIR/packages

if (( $is_mast_ctrl_node == 0 ));then
	echo "��ǰ�����������õ����ڵ㣬������ִ��setup2.sh"
	exit 1
fi
#mjx compute
echo "scaleone���尲װ,����a;�������Ӽ���ڵ㰲װ������c."
read mode

if [ "a" != $mode -a  "c" != $mode ]; then
echo "�������Ϸ�"
exit 1
fi

#���尲װʱ��Ҫִ�еĴ��뿪ʼ
if [ "a" = $mode ]; then  
#������
ifconfig br0:0 10.0.0.254 netmask 255.255.255.0 up

echo "create mast ctrl_node"
mkdir -p /opt/no_db_ctrl
cp $INSTALL_PACKAGE_PATH/ubuntu.img /opt/no_db_ctrl
cp $INSTALL_PACKAGE_PATH/libvirt_ctrl.xml /opt/no_db_ctrl
sed -i "s%^DBServer=.*$%DBServer=$virtual_ctrl_IP%g" $INSTALL_PACKAGE_PATH/openstack_install.sh
virsh create /opt/no_db_ctrl/libvirt_ctrl.xml
sed -i "s%^address.*$%address $mast_ctrl_IP%g" $BASE_DIR/config/interfaces_ctrl
sed -i "s%^netmask.*$%netmask $mast_ctrl_netmask%g" $BASE_DIR/config/interfaces_ctrl 
sed -i "s%^gateway.*$%gateway $mast_ctrl_gateway%g" $BASE_DIR/config/interfaces_ctrl 

#sed -i "s%^eth2_address.*$%address $mast_HA_ip%g" $BASE_DIR/config/interfaces_ctrl
#sed -i "s%^eth2_address.*$%netmask $mast_HA_mask%g" $BASE_DIR/config/interfaces_ctrl 
#mjx function
add_torclocal "virsh create /opt/no_db_ctrl/libvirt_ctrl.xml"  /etc/rc.local
sleep 90
./scp_file.sh 10.0.0.200 root intple $BASE_DIR/config/interfaces_ctrl /etc/network/interfaces
./ssh_exec.sh 10.0.0.200 root intple "/etc/init.d/networking restart &" &



if [[ $is_support_master_slave == "yes" ]];then
  sleep 10
	echo "create slave ctrl_node"
	./ssh_exec.sh $slavenodeIP root $slavenodepasswd "mkdir -p /opt/no_db_ctrl"
	./scp_file.sh $slavenodeIP root $slavenodepasswd $INSTALL_PACKAGE_PATH/ubuntu.img /opt/no_db_ctrl
	./scp_file.sh $slavenodeIP root $slavenodepasswd $INSTALL_PACKAGE_PATH/libvirt_ctrl.xml /opt/no_db_ctrl
	./ssh_exec.sh $slavenodeIP root $slavenodepasswd "virsh create /opt/no_db_ctrl/libvirt_ctrl.xml"
	cp $BASE_DIR/config/interfaces_ctrl $BASE_DIR/config/interfaces_ctrl_slave
	sed -i "s%^address.*$%address $slave_ctrl_IP%g" $BASE_DIR/config/interfaces_ctrl_slave
	sed -i "s%^netmask.*$%netmask $slave_ctrl_netmask%g" $BASE_DIR/config/interfaces_ctrl_slave 
	sed -i "s%^gateway.*$%gateway $slave_ctrl_gateway%g" $BASE_DIR/config/interfaces_ctrl_slave 
	
#	sed -i "s%^eth2_address.*$%address $slave_HA_ip%g" $BASE_DIR/config/interfaces_ctrl_slave
#	sed -i "s%^eth2_address.*$%netmask $slave_HA_mask%g" $BASE_DIR/config/interfaces_ctrl_slave
	./ssh_exec.sh $slavenodeIP root $slavenodepasswd "echo \"virsh create /opt/no_db_ctrl/libvirt_ctrl.xml\" >> /etc/rc.local"
	sleep 90
	./scp_file.sh 10.0.0.200 root intple $BASE_DIR/config/interfaces_ctrl_slave /etc/network/interfaces
	./ssh_exec.sh 10.0.0.200 root intple "/etc/init.d/networking restart &" &

else
	echo "����û�����ã����ڵ�û�д���" 
fi

sleep 10
virpasswd=intple
ifconfig br0:0 down

#�滻������ַ���
sed -i s%HA_FLOAT_IP%$virtual_ctrl_IP%g $BASE_DIR/install/ha/ha_check_run_work.sh

#�����ƽڵ�ִ�еĽű�
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/openstack_install.sh /root/openstack_install.sh
./scp_file.sh $mast_ctrl_IP root $virpasswd $BASE_DIR/config/scaleone.properties /root/scaleone.properties
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/CreateTable.sql /home/intple/CreateTable.sql
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/openstack.iso /root/openstack.iso
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/alarm.tar.gz /home/intple/alarm.tar.gz
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/scaleone_monitor.tar /opt/scaleone_monitor.tar
./scp_file.sh $mast_ctrl_IP root $virpasswd $BASE_DIR/install/virtual_db.sh /root/virtual_db.sh
#mjx function
./scp_file.sh $mast_ctrl_IP root $virpasswd $BASE_DIR/install/add_torclocal.sh /root/add_torclocal.sh
./ssh_exec.sh $mast_ctrl_IP root $virpasswd "mkdir -p /etc/scaleone/ha/"
for i in `ls $BASE_DIR/install/ha/`
do
./scp_file.sh $mast_ctrl_IP root $virpasswd $BASE_DIR/install/ha/$i /etc/scaleone/ha/
done
./ssh_exec.sh $mast_ctrl_IP root $virpasswd "chmod 777 /etc/scaleone/ha/*.sh"
./ssh_exec.sh $mast_ctrl_IP root $virpasswd  "mkdir -p /opt/scaleone_ftp/"
for i in `ls $BASE_DIR/install/scaleone_ftp/`
do
./scp_file.sh $mast_ctrl_IP root $virpasswd  $BASE_DIR/install/scaleone_ftp/$i /opt/scaleone_ftp/
done
  
mask2prifex $virtual_ctrl_netmask
sed -i s%HA_ETH_NAME%$mastinterface%g $BASE_DIR/config/mast_keepalived.conf
sed -i s%GROUP_ID%$groupid%g $BASE_DIR/config/mast_keepalived.conf
sed -i s%VIRTUAL_CTLL_IP%$virtual_ctrl_IP/$PRIFEX%g $BASE_DIR/config/mast_keepalived.conf
./ssh_exec.sh $mast_ctrl_IP root $virpasswd "mkdir -p /etc/keepalived/"
./scp_file.sh $mast_ctrl_IP root $virpasswd $BASE_DIR/config/mast_keepalived.conf /etc/keepalived/keepalived.conf

./ssh_exec.sh $mast_ctrl_IP root $virpasswd "/root/openstack_install.sh db"
./ssh_exec.sh $mast_ctrl_IP root $virpasswd "/root/virtual_db.sh"

sleep 10
./scp_file.sh $mast_ctrl_IP root $virpasswd $BASE_DIR/install/virtual_ctrl.sh /root/virtual_ctrl.sh
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/scaleone.tar.gz /opt/scaleone.tar.gz

if [[ $is_support_master_slave == "no" ]];then
./ssh_exec.sh $mast_ctrl_IP root $virpasswd "/root/virtual_ctrl.sh"
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/ScaleOneClient.exe /opt/scaleone/webapps/vmm/scaleOneClient/ScaleOneClient.exe
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/ScaleOneClient.exe /opt/scaleone/webapps/user/scaleOneClient/ScaleOneClient.exe
#�л���������keepalive ���ű�
./ssh_exec.sh $mast_ctrl_IP root $virpasswd "mv /etc/scaleone/ha/ha_check_run_work.sh /etc/scaleone/ha/ha_check_run.sh"
fi



#�ӿ��ƽڵ�ִ�еĽű�
if [[ $is_support_master_slave == "yes" ]];then
	sleep 10
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/openstack_install.sh /root/openstack_install.sh
	./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/config/scaleone.properties /root/scaleone.properties
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/CreateTable.sql /home/intple/CreateTable.sql
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/openstack.iso /root/openstack.iso
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/alarm.tar.gz /home/intple/alarm.tar.gz
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/scaleone_monitor.tar /opt/scaleone_monitor.tar
	./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/install/virtual_db.sh /root/virtual_db.sh
  ./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/install/add_torclocal.sh /root/add_torclocal.sh
  
  ./ssh_exec.sh $slave_ctrl_IP root $virpasswd "mkdir -p /etc/scaleone/ha/"
	for i in `ls $BASE_DIR/install/ha/`
	do
	./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/install/ha/$i /etc/scaleone/ha/
	done
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd "chmod 777 /etc/scaleone/ha/*.sh"
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd  "mkdir -p /opt/scaleone_ftp/"
	for i in `ls $BASE_DIR/install/scaleone_ftp/`
	do
	./scp_file.sh $slave_ctrl_IP root $virpasswd  $BASE_DIR/install/scaleone_ftp/$i /opt/scaleone_ftp/
	done
	
	mask2prifex $virtual_ctrl_netmask
	sed -i s%HA_ETH_NAME%$mastinterface%g $BASE_DIR/config/mast_keepalived.conf
	sed -i s%VIRTUAL_CTLL_IP%$virtual_ctrl_IP/$PRIFEX%g $BASE_DIR/config/mast_keepalived.conf
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd "mkdir -p /etc/keepalived/"
	./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/config/mast_keepalived.conf /etc/keepalived/keepalived.conf

   ./ssh_exec.sh $slave_ctrl_IP root $virpasswd "/root/openstack_install.sh db"
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd "/root/virtual_db.sh"
	
	#mjx database
	#�޸��������ݿ�������ļ�������
	chmod 777  $BASE_DIR/install/db/*
	./scp_file.sh $mast_ctrl_IP root $virpasswd  $BASE_DIR/install/db/master_change_conf.sh  /root/master_change_conf.sh
	./ssh_exec.sh $mast_ctrl_IP root $virpasswd  "/root/master_change_conf.sh"
	
	./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/install/db/slave_change_conf.sh  /root/slave_change_conf.sh
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd "/root/slave_change_conf.sh"
	#ִ�л�ȡFILE��POS
	./scp_file.sh $mast_ctrl_IP root $virpasswd  $BASE_DIR/install/db/master_get_status.sh  /root/master_get_status.sh
	./ssh_exec.sh $mast_ctrl_IP root $virpasswd  "/root/master_get_status.sh"
	 
  ./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/install/db/slave_get_status.sh   /root/slave_get_status.sh 
  ./ssh_exec.sh $slave_ctrl_IP root $virpasswd "/root/slave_get_status.sh"
  
  #��FILE POS����
  #./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/install/${mast_ctrl_IP}_var_status   /root/${mast_ctrl_IP}_var_status
  ./scp_get.sh  $slave_ctrl_IP root $virpasswd /root/${slave_ctrl_IP}_var_status $BASE_DIR/install/db/${slave_ctrl_IP}_var_status
  ./scp_get.sh  $mast_ctrl_IP  root $virpasswd /root/${mast_ctrl_IP}_var_status $BASE_DIR/install/db/${mast_ctrl_IP}_var_status
  
	./scp_file.sh $mast_ctrl_IP  root $virpasswd $BASE_DIR/install/db/${slave_ctrl_IP}_var_status   /root/${slave_ctrl_IP}_var_status
	./scp_file.sh $slave_ctrl_IP  root $virpasswd $BASE_DIR/install/db/${mast_ctrl_IP}_var_status   /root/${mast_ctrl_IP}_var_status
	
	#ִ��SQL�Ľ���FILE,POS
	./scp_file.sh $mast_ctrl_IP  root $virpasswd $BASE_DIR/install/db/master_exchange_info.sh   /root/master_exchange_info.sh
	./scp_file.sh $slave_ctrl_IP  root $virpasswd $BASE_DIR/install/db/slave_exchange_info.sh   /root/slave_exchange_info.sh
	
	./ssh_exec.sh $mast_ctrl_IP root $virpasswd  "/root/master_exchange_info.sh"
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd  "/root/slave_exchange_info.sh"
	
	#������������slave
	./scp_file.sh $mast_ctrl_IP  root $virpasswd $BASE_DIR/install/db/start_slave.sh   /root/start_slave.sh
	./scp_file.sh $slave_ctrl_IP  root $virpasswd $BASE_DIR/install/db/start_slave.sh   /root/start_slave.sh
	
	./ssh_exec.sh $mast_ctrl_IP root $virpasswd  "/root/start_slave.sh"
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd  "/root/start_slave.sh"
	
	
	sleep 10
	./ssh_exec.sh $mast_ctrl_IP root $virpasswd "/root/virtual_ctrl.sh"
	./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/ScaleOneClient.exe /opt/scaleone/webapps/vmm/scaleOneClient/ScaleOneClient.exe
  ./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/ScaleOneClient.exe /opt/scaleone/webapps/user/scaleOneClient/ScaleOneClient.exe
  #�л���������keepalive ���ű�
  ./ssh_exec.sh $mast_ctrl_IP root $virpasswd "mv /etc/scaleone/ha/ha_check_run_work.sh /etc/scaleone/ha/ha_check_run.sh"
  
  ./scp_file.sh $slave_ctrl_IP root $virpasswd $BASE_DIR/install/virtual_ctrl.sh /root/virtual_ctrl.sh
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/scaleone.tar.gz /opt/scaleone.tar.gz
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd "/root/virtual_ctrl.sh"
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/ScaleOneClient.exe /opt/scaleone/webapps/vmm/scaleOneClient/ScaleOneClient.exe
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/ScaleOneClient.exe /opt/scaleone/webapps/user/scaleOneClient/ScaleOneClient.exe
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd "mv /etc/scaleone/ha/ha_check_run_work.sh /etc/scaleone/ha/ha_check_run.sh"
fi


echo "ctrl node completed"

fi
#���尲װʱ��Ҫִ�еĴ������


rm -rf $INSTALL_PACKAGE_PATH/authorized_keys
rm -rf $INSTALL_PACKAGE_PATH/hosts
echo "127.0.0.1 localhost" > $INSTALL_PACKAGE_PATH/hosts
i=0
while [ $i -lt $resource_node_count ]
do
  
  #ȷ�ϸû�������û��װ����ڵ�
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "dpkg -l nova-compute|tee /root/nova-compute.log"
	./scp_get.sh ${resource_IP[$i]} root ${resource_passwd[$i]} /root/nova-compute.log  $BASE_DIR/install/nova_compute_${resource_IP[$i]}
	grep "OpenStack Compute"  $BASE_DIR/install/nova_compute_${resource_IP[$i]}
	#û��װ�Ļ���װ������ڵ�
	if [ $? -eq 1 ]; then
	./scp_file.sh ${resource_IP[$i]} root ${resource_passwd[$i]} $INSTALL_PACKAGE_PATH/openstack_install.sh /root/openstack_install.sh
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "sed -i s%^ControlServAddr=.*$%ControlServAddr=$virtual_ctrl_IP%g /root/openstack_install.sh"
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "sed -i s%^DBServer=.*$%DBServer=$virtual_ctrl_IP%g /root/openstack_install.sh"
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "sed -i s%^NovaComputNetInterface.*$%NovaComputNetInterface=${vmnet_eth_name[i]}%g /root/openstack_install.sh"
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "sed -i s%^NovaComputManagerInterface.*$%NovaComputManagerInterface=${manager_eth_name[i]}%g /root/openstack_install.sh"
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "/root/resource.sh"
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "iptables -I FORWARD -s $dhcp_ip  --sport 67 -j DROP > /dev/null 2>&1 &"
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "sed -i s%^server_proxyclient_address.*$%server_proxyclient_address=${desk_view_ip[$i]}%g /etc/nova/nova.conf"
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "/etc/init.d/nova-compute restart"
	./scp_file.sh ${resource_IP[$i]} root ${resource_passwd[$i]} $INSTALL_PACKAGE_PATH/nova-heartbeat.sh /etc/scaleone/nova-heartbeat.sh
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "chmod 777 /etc/scaleone/nova-heartbeat.sh"
	fi
	#mjx ��֤��Ҫ��������һ��
	echo "${resource_IP[$i]} ${resource_name[$i]}" >> $INSTALL_PACKAGE_PATH/hosts
	i=`expr $i + 1`
done

#mjx ���Ӽ���ڵ�ʱ��������Ҫ������һ��
virpasswd=intple
add_torclocal "::1     ip6-localhost ip6-loopback"  $INSTALL_PACKAGE_PATH/hosts
add_torclocal "fe00::0 ip6-localnet"  $INSTALL_PACKAGE_PATH/hosts
add_torclocal "ff00::0 ip6-mcastprefix"  $INSTALL_PACKAGE_PATH/hosts
add_torclocal "ff02::1 ip6-allnodes"  $INSTALL_PACKAGE_PATH/hosts
add_torclocal "ff02::2 ip6-allrouters"  $INSTALL_PACKAGE_PATH/hosts

./ssh_exec.sh $mast_ctrl_IP root $virpasswd "mv /etc/hosts /etc/hosts.bak"
./scp_file.sh $mast_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/hosts /etc/hosts

if [[ $is_support_master_slave == "yes" ]];then
	./ssh_exec.sh $slave_ctrl_IP root $virpasswd "mv /etc/hosts /etc/hosts.bak"
	./scp_file.sh $slave_ctrl_IP root $virpasswd $INSTALL_PACKAGE_PATH/hosts /etc/hosts
fi

i=0
while [ $i -lt $resource_node_count ]
do
	./ssh_exec.sh ${resource_IP[$i]} root ${resource_passwd[$i]} "mv /etc/hosts /etc/hosts.bak"
	./scp_file.sh ${resource_IP[$i]} root ${resource_passwd[$i]} $INSTALL_PACKAGE_PATH/hosts /etc/hosts
	i=`expr $i + 1`
done	
./rsa.sh
