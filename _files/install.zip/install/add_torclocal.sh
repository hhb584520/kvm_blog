#!/bin/bash
function add_torclocal()
{
   grep "^${1}"  $2 > /dev/null 2>&1
   if [ $? -ne 0 ]; then
     echo $1 >>$2
   fi

}


