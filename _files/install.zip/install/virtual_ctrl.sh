#!/bin/bash
#set -x
. ./scaleone.properties
#mjx function
. ./add_torclocal.sh

BASE_DIR=$PWD
INSTALL_PACKAGE_PATH=$BASE_DIR
sudo apt-get install -y --force-yes keepalived
sleep 10
sudo /root/openstack_install.sh control
sudo /root/openstack_install.sh network
sudo apt-get install python-libvirt
sudo apt-get -f install
sudo apt-get install python-libvirt

sudo apt-get install -y --force-yes vsftpd
sudo apt-get install -y --force-yes db-util

cd /home/intple;tar -zxvf /home/intple/alarm.tar.gz
cd /home/intple/alarm;chmod +x install;./install

cd /opt;tar -zxvf scaleone.tar.gz
cd /opt/scaleone/webapps;mkdir vmm;cd vmm
/opt/scaleone/jdk1.7.0_21/bin/jar -xvf /opt/scaleone/webapps/vmm.war
cd /opt/scaleone/webapps;mkdir manage;cd manage
/opt/scaleone/jdk1.7.0_21/bin/jar -xvf /opt/scaleone/webapps/manage.war
cd /opt/scaleone/webapps;mkdir user;cd user
/opt/scaleone/jdk1.7.0_21/bin/jar -xvf /opt/scaleone/webapps/user.war
sed -i "s%localhost:3306%$virtual_ctrl_IP:3306%g" /opt/scaleone/webapps/vmm/WEB-INF/spring/root-context.xml
sed -i "s%localhost:3306%$virtual_ctrl_IP:3306%g" /opt/scaleone/webapps/manage/WEB-INF/spring/root-context.xml
#sed -i "s%^vmIpRang.*$%vmIpRang=$sharednet%g" /usr/local/etc/alarm.cfg
sed -i "s%^DB_HOSTNAME.*$%DB_HOSTNAME = $virtual_ctrl_IP%g" /usr/local/etc/alarm.cfg
sed -i "s%^host.*$%host=$virtual_ctrl_IP%g" /opt/scaleone/webapps/vmm/WEB-INF/classes/config.properties
sed -i "s%^manageIP.*$%manageIP=$scaleone_manger_ip%g" /opt/scaleone/webapps/user/WEB-INF/classes/config.properties
sed -i "s%^manageIP.*$%manageIP=$scaleone_manger_ip%g" /opt/scaleone/webapps/vmm/WEB-INF/classes/config.properties

cd /opt;tar -xvf scaleone_monitor.tar
sed -i "s%^DBIP.*$%DBIP=$virtual_ctrl_IP%g" /opt/scaleone_monitor/manager/monitor.cfg 
sed -i "s%^GROUPID.*$%GROUPID=$groupid%g" /opt/scaleone_monitor/manager/monitor.cfg 
#cd /opt/scaleone_monitor/manager; ./manager & > /dev/null 2>&1 &


/usr/local/sbin/alarm.py > /dev/null 2>&1 &
sed -i "/^exit 0/d" /etc/rc.local
#mjx function
add_torclocal "/etc/scaleone/ha/ha_power_init.sh > /dev/null 2>&1 &"  /etc/rc.local

#init vsftp 
chmod 777 /opt/scaleone_ftp/*.sh
cd /opt/scaleone_ftp/; ./vsftp_init.sh
echo "glance ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers

ifconfig eth1 up
ovs-vsctl add-port br-eth1 eth1
add_torclocal "ifconfig eth1 up"  /etc/rc.local

sed -i "s%^share_disk.*$%share_disk=$share_disk%g" /etc/nova/nova.conf
/etc/init.d/nova-api restart > /dev/null 2>&1 &
#mjx �ڴ泬��
sed -i "s%^ram_allocation_ratio.*$%ram_allocation_ratio=$mem_ratio%g" /etc/nova/nova.conf
/etc/init.d/nova-scheduler restart > /dev/null 2>&1 &

echo "start do scaleone shutdown.sh"
/opt/scaleone/bin/shutdown.sh > /dev/null 2>&1 &
sleep 5
pkill -9 java
echo "start do scaleone startup.sh"
/opt/scaleone/bin/startup.sh > /dev/null 2>&1 &

