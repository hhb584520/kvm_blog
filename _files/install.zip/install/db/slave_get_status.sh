#!/bin/bash
. ./scaleone.properties
echo "FLUSH TABLES WITH READ LOCK;
SHOW MASTER STATUS;
UNLOCK TABLES;
">get_status.sql
mysql -uroot -pintple<get_status.sql>out_status

FILE=`cat out_status | sed -e '1d' | awk -F ' ' '{print $1}'`
POS=`cat out_status | sed -e '1d' | awk -F ' ' '{print $2}'`
echo "FILE=${FILE}">${slave_ctrl_IP}_var_status
echo "POS=${POS}">>${slave_ctrl_IP}_var_status
