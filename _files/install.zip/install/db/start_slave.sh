echo "start slave">start_slave.sql
mysql -uroot -pintple<start_slave.sql
