#!/bin/bash
. ./scaleone.properties
. ./${mast_ctrl_IP}_var_status
echo  "stop slave;
CHANGE MASTER TO MASTER_HOST='${mast_ctrl_IP}',MASTER_USER='root',MASTER_PASSWORD='intple',MASTER_LOG_FILE='${FILE}',MASTER_LOG_POS=${POS};">exchange.sql
mysql -uroot -pintple<exchange.sql

