grep "server-id = 20" /etc/mysql/my.cnf
if [ $? -ne 0 ]; then
  sed -i "/\[mysqld\]/a\server-id = 20\nlog-bin = mysql-bin\nauto-increment-increment = 2\nauto-increment-offset = 2\nslave-skip-errors=all" /etc/mysql/my.cnf
fi
service mysql restart
echo  "stop slave" >stop_slave.sql
mysql -uroot -pintple <stop_slave.sql>stop.log 2>&1
