#!/bin/bash
. ./scaleone.properties

sed -i "/\[mysqld\]/a\character-set-server=utf8" /etc/mysql/my.cnf
sed -i "/\[mysqld\]/a\binlog_format = 'MIXED'" /etc/mysql/my.cnf

service mysql restart
echo -e "\nGRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'intple' WITH GRANT OPTION; " >> /home/intple/CreateTable.sql

sed -i "s%CONTROLNODE_DEFAULT%$masthostname%g" /home/intple/CreateTable.sql
if [ "yes" = $share_disk ]; then  
    sed -i "s%DISK_SHARE_MODE%share%g" /home/intple/CreateTable.sql  
else
    sed -i "s%DISK_SHARE_MODE%unshare%g" /home/intple/CreateTable.sql  
fi  
#mjx �ڴ泬��
sed -i "s%MEM_RATIO%$mem_ratio%g" /home/intple/CreateTable.sql

mysql -uroot -pintple < /home/intple/CreateTable.sql
cd /opt;tar -xvf scaleone_monitor.tar
mysql -uroot -pintple < /opt/scaleone_monitor/Createmonitortable.sql
cd /home/intple;tar -zxvf /home/intple/alarm.tar.gz;chmod +x /home/intple/alarm/createtables
/home/intple/alarm/createtables > /dev/null 2>&1 &