#!/bin/bash

server=`ls -l /etc/init.d |grep nova |awk '{print $9}'`
for i in $server
do
	/etc/init.d/$i stop
done

server=`ls -l /etc/init.d |grep glance |awk '{print $9}'`
for i in $server
do
	/etc/init.d/$i stop
done
server=`ls -l /etc/init.d |grep quantum |awk '{print $9}'`
for i in $server
do
	/etc/init.d/$i stop
done
server=`ls -l /etc/init.d |grep keystone |awk '{print $9}'`
for i in $server
do
	/etc/init.d/$i stop
done
