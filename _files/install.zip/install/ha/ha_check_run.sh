#!/bin/bash

echo "install success will be repair"
exit 0