#!/bin/bash

#openstack��manager��������

cd /opt/scaleone_monitor/manager/; ./manager > /dev/null 2>&1 &
/usr/local/sbin/alarm.py > /dev/null 2>&1 &
sleep 10
/opt/scaleone/bin/startup.sh > /dev/null 2>&1 &
