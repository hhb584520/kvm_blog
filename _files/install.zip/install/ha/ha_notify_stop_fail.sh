#!/bin/bash

# reboot system
reboot