#!/bin/bash

#monitor_flag=`ps -Alf |grep ./manager -c`
#alarm_flag=`ps -Alf |grep alarm.py -c`
db_flag=`netstat -anp | grep LISTEN | grep 3306 -c`

if  [ ! -f  /var/run/keepfirststart  ];  then
 
   echo "first start, don't check" >> /etc/scaleone/ha/log.log
   echo 3 > /var/run/keepfirststart
   exit 0
fi

ha_ip_exit=`ip a | grep HA_FLOAT_IP -c`
if  [ ! -f  /var/run/keepfirststart_ip  ];  then
		if ((  $ha_ip_exit != 0 )); then
			echo 1 > /var/run/keepfirststart_ip
			echo "get float ip, start float ip check" >> /etc/scaleone/ha/log.log
		fi
else
		if ((  $ha_ip_exit == 0 )); then
			echo "float ip existed, now does not exist" >> /etc/scaleone/ha/log.log
			reboot
		fi
fi

if ((  $db_flag == 0 )); then
	num=`cat /var/run/keepfirststart`
	if (( $num != 0 ));then
		num=`expr $num - 1`
		echo "$num" > /var/run/keepfirststart
		echo "wait mysql startup....., $num count" >> /etc/scaleone/ha/log.log
		exit 0
	fi
	
	mkdir -p /etc/scaleone/ha/
	echo "db exception , flag = $db_flag" >> /etc/scaleone/ha/log.log
	reboot
	exit 0
fi
exit 0