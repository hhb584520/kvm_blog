#!/bin/bash

mkdir -p /home/vsftpd
useradd vsftpd -d /home/vsftpd -s /sbin/nologin
mkdir -p /home/vsftpd/ftpuser
mkdir -p /home/vsftpd/ftpuser/admin
chmod a-w /home/vsftpd/ftpuser/admin

chown -R vsftpd:vsftpd /home/vsftpd/ftpuser/

mkdir -p /etc/vsftpd/login_db
echo "admin" > /etc/vsftpd/login_db/login.txt
echo "lxc" >> /etc/vsftpd/login_db/login.txt
db_load -T -t hash -f /etc/vsftpd/login_db/login.txt /etc/vsftpd/login_db/login.db

chmod 600 /etc/vsftpd/login_db/login.db

mkdir -p /etc/vsftpd/user_conf
cp ./admin /etc/vsftpd/user_conf/
cp -f ./vsftpd.conf /etc/
cp -f ./vsftpd.vu  /etc/pam.d/

grep "^/var/lib/glance/images localhost(rw,sync,no_root_squash)"  /etc/exports > /dev/null 2>&1
if [ $? -ne 0 ]; then
 echo "/var/lib/glance/images localhost(rw,sync,no_root_squash)" >> /etc/exports
fi

service nfs-kernel-server restart > /dev/null 2>&1

service vsftpd restart

