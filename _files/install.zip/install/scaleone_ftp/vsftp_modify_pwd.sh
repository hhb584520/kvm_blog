#!/bin/bash

user=$1
pwd=$2
id=$3
name=$4

if [[ $pwd == "" ]];then
	echo "passwd does not null"
	exit 1
fi

mkdir -p /var/lib/glance/images/ftp_path

umount -l /home/vsftpd/ftpuser/admin
mount --bind /var/lib/glance/images/ftp_path /home/vsftpd/ftpuser/admin
chmod a-w /home/vsftpd/ftpuser/admin
mv /var/lib/glance/images/$id /var/lib/glance/images/ftp_path/$name
chown -R vsftpd:vsftpd /home/vsftpd/ftpuser/admin



echo "$user" > /etc/vsftpd/login_db/login.txt
echo "$pwd" >> /etc/vsftpd/login_db/login.txt
db_load -T -t hash -f /etc/vsftpd/login_db/login.txt /etc/vsftpd/login_db/login.db

service vsftpd restart
